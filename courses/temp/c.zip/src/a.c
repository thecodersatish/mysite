//C program
#include<stdio.h>

int main(){
    printf("Hello world");
}