f = open("a.txt","r")
print(len(f.readlines()))